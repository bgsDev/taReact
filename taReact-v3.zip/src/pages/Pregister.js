import React from 'react';
import { useDispatch } from 'react-redux';
import { FiKey, FiMail, FiUser } from 'react-icons/fi';
import { Link, useNavigate } from 'react-router-dom';
import { FinputG } from '../components/Finput';
import { useInput } from '../hooks/useInput';
import { JudulHr } from '../components/sf/JudulHr';
import { actRegisterUser } from '../states/users/action';

function Pregister() {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const [user, setUser] = useInput('');
  const [email, setEmail] = useInput('');
  const [pass, setPass] = useInput('');

  const oncForm = async (event) => {
    event.preventDefault();
    dispatch(actRegisterUser({ name: user, email, password: pass }));
    navigate('/login');
  };
  return (
    <form className="boxRadius15 QuicksandLight" onSubmit={oncForm}>
      <JudulHr judul="Register" cls="talgC" />
      <FinputG
        icon={<FiUser />}
        clsIcon="minWinForm cblack"
        cls=""
        plac="User"
        type="text"
        value={user}
        onchange={setUser}
      />
      <FinputG
        icon={<FiMail />}
        clsIcon="minWinForm cblack "
        cls=" cblack"
        plac="Email"
        type="email"
        value={email}
        onchange={setEmail}
      />
      <FinputG
        icon={<FiKey />}
        clsIcon="minWinForm cblack"
        cls=""
        plac="password"
        type="password"
        value={pass}
        onchange={setPass}
      />
      <br />
      <button type="submit" className="btnLink">Daftar</button>
      <br />
      <br />
      <p className="cblack">
        Kembali ke ?
        <Link to="/login" className="btnLink"><b> Login</b></Link>
      </p>
    </form>
  );
}
export default Pregister;
