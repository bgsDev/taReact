/* eslint-disable no-undef */
/* eslint-disable import/named */
/* eslint-disable import/no-extraneous-dependencies */
import React from 'react';
import { useDispatch } from 'react-redux';
import { FiKey, FiMail } from 'react-icons/fi';
import { Link } from 'react-router-dom';
import { FinputG } from '../components/Finput';
import { useInput } from '../hooks/useInput';
import { JudulHr } from '../components/sf/JudulHr';
import { actSetAuthUser } from '../states/authUser/action';

function Plogin() {
  const dispatch = useDispatch();

  const [email, setEmail] = useInput('');
  const [pass, setPass] = useInput('');

  const oncForm = async (event) => {
    event.preventDefault();
    dispatch(actSetAuthUser({ email, password: pass }));
  };
  return (
    <form className="boxRadius15  QuicksandLight " onSubmit={oncForm}>
      <JudulHr judul="Login" cls="talgC" />
      <FinputG
        icon={<FiMail />}
        clsIcon="minWinForm cblack "
        cls=" cblack"
        plac="Email"
        type="email"
        value={email}
        onchange={setEmail}
      />
      <FinputG
        icon={<FiKey />}
        clsIcon="minWinForm cblack"
        cls=""
        plac="password"
        type="password"
        value={pass}
        onchange={setPass}
      />
      <br />
      <button type="submit" className="btnLink">Login</button>
      <br />
      <br />
      <p>
        Buat akun baru?
        <Link to="/register" className="btnLink"><b> register</b></Link>
      </p>
    </form>
  );
}
export default Plogin;
